# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts', 'brain_games.scripts.games']

package_data = \
{'': ['*'], 'brain_games.scripts': ['games/.idea/*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = '
                     'brain_games.scripts.games.brain_calc:play_calc_game',
                     'brain-even = '
                     'brain_games.scripts.games.brain_even:play_parity_check_game',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.games.brain_gcd:play_gcd',
                     'brain-progression = '
                     'brain_games.scripts.games.brain_progression:play_brain_progression_game']}

setup_kwargs = {
    'name': 'sergsm-brain-games',
    'version': '0.1.10',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
